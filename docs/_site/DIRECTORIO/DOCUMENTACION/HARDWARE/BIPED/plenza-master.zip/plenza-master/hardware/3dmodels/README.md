# plenza

A PLEN Robot Derivative designed at BinarySpace (South Africa). We love the PLEN2 robot but its expensive and some parts are hard or too expensive to get in South Africa. This is our take on a lower cost version of the PLEN2 robot using 9g servo's.

The 3d printed parts are inspired by the PLEN2 parts but were redrawn from scratch to make use of the cheaper 9g servo motors. Parts were designed by Andries Smuts.

Note: This is a work in progress. We are still busy building and testing it. Proceed at own risk :)

www.binaryspace.co.za



