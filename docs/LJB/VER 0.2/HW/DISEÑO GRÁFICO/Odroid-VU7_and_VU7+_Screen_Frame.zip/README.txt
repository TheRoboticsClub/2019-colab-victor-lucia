                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2779451
Odroid-VU7 and VU7+ Screen Frame by Zurkeyon is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

General Purpose Protective Screen Frame for the ODROID VU-7 and VU-7+ Screens. 

For use in other projects. 

Sketchup files are included. Modify to your liking. 

Prints on any 8x8+ Prusa or Other. 

Small m2 or m3 hardware will hold the 2 halves together. 

Left somewhat open in the back for venting, as I put mine into a vehicle application and used ABS. 

You can easily fill those in for a more contained unit. 

I have also included a sliding rail that will glue onto the back of the screen. It has an up and a down position, and can also be modified to your liking, or excluded entirely. 

Its simply one I had ready-made I thought I would include. 

Enjoy! 

(Current version should hide the screen edges better than in the pics, if not its easy to modify.)